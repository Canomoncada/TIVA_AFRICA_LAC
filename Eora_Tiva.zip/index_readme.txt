The index_[t|y|v|q].csv files contain sector labels for the MRIO table.
The Q index describes rows in the satellite block
The M index describes rows/columns in the complete MRIO table with Primary Input and Final Demand rows included interwoven with Industry and Commodity blocks
The T index describes rows or columns in the MRIO table, with Final demand and Primary input rows/columns removed
The V and Y indices describe rows/columns for Primary Inputs (V) and Final Demand (Y), concatenated together	
